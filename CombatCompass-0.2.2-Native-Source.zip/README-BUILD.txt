Combat Compass 0.2.2 native corresponding source
The native plugin and combined DLL use GPL-3.0-or-later. CommonLib's exceptions
permit interaction with Skyrim and the named modding libraries; retain the
included GPL/exception documents. Third-party source retains its stated license.
This package contains the exact native routing/adapter sources, dependency
sources and local build glue used for the 0.2.2 candidate.

Build on Linux with clang-cl 23.1.1, lld-link, llvm-lib, llvm-rc, llvm-mt,
Ninja and CMake 3.24+ (the recorded build used 4.4.4).
Provide an independently licensed Microsoft VC/Windows SDK xwin sysroot at
vendor/native-build/windows-sysroot (CRT 14.44 and Windows SDK 10.0.26100).
These compiler/System Library SDK files and Skyrim are not distributed here.
Run bash experiments/latest-runtime/build_windows.sh.
Output: build/native-latest-windows/CombatCompass.dll.
DirectXTK uses only its upstream SimpleMath component; its two whitespace
tokens are corrected by the included patch/build script. CommonLib's unused
trampoline patch-safety module and IPO are off. AE-only layout support is on;
the mod's entry point accepts exactly 1.6.1170 and 1.7.104.
No game data, Address Library binaries, player paths/logs or generated caches
are included. For address-probe testing supply your own matching game executable
and Address Library data. The plugin/routing interface to Papyrus is unchanged.

2026-10-13 road feedback update
The native DLL and C++ sources remain unchanged. The binary releases now
use a controller script that displays "return to road to use this power" for empty searches.
Its Papyrus source is included at papyrus/RN_Controller.psc. Compiling the
script requires the Bethesda Papyrus compiler and the matching game, SKSE,
PapyrusUtil, UIExtensions and other mod script includes supplied separately.
