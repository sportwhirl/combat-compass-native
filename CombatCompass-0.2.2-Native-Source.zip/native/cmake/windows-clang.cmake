# Linux -> Windows x64, using the existing LLVM tools and project-local xwin SDK.
# SDK acquisition/license acceptance is a separate, explicitly approved step.
set(CMAKE_SYSTEM_NAME Windows)
set(CMAKE_SYSTEM_PROCESSOR AMD64)
get_filename_component(CC_PROJECT_ROOT "${CMAKE_CURRENT_LIST_DIR}/../.." ABSOLUTE)
set(CC_SYSROOT "${CC_PROJECT_ROOT}/vendor/native-build/windows-sysroot" CACHE PATH "xwin SDK/CRT root")
if(NOT EXISTS "${CC_SYSROOT}/crt/include/vector" OR
   NOT EXISTS "${CC_SYSROOT}/sdk/include/um/Windows.h")
  message(FATAL_ERROR "Project-local Windows SDK/CRT is missing. License approval and SDK staging are required first.")
endif()
set(CMAKE_C_COMPILER /usr/bin/clang-cl)
set(CMAKE_CXX_COMPILER /usr/bin/clang-cl)
set(CMAKE_LINKER /usr/bin/lld-link)
set(CMAKE_AR /usr/bin/llvm-lib)
set(CMAKE_RC_COMPILER /usr/bin/llvm-rc)
set(CMAKE_MT /usr/bin/llvm-mt)
# Real link checks prevent CMake from falsely detecting pthreads on Windows.
set(CMAKE_TRY_COMPILE_TARGET_TYPE EXECUTABLE)
set(CMAKE_MSVC_RUNTIME_LIBRARY MultiThreadedDLL)
set(CC_SYSTEM_INCLUDES
  "/imsvc\"${CC_SYSROOT}/crt/include\" /imsvc\"${CC_SYSROOT}/sdk/include/ucrt\" /imsvc\"${CC_SYSROOT}/sdk/include/shared\" /imsvc\"${CC_SYSROOT}/sdk/include/um\" /imsvc\"${CC_SYSROOT}/sdk/include/winrt\"")
set(CMAKE_C_FLAGS_INIT "${CC_SYSTEM_INCLUDES}")
set(CMAKE_CXX_FLAGS_INIT "/EHsc /utf-8 ${CC_SYSTEM_INCLUDES}")
set(CC_LINK_DIRS
  "/libpath:\"${CC_SYSROOT}/crt/lib/x86_64\" /libpath:\"${CC_SYSROOT}/sdk/lib/ucrt/x86_64\" /libpath:\"${CC_SYSROOT}/sdk/lib/um/x86_64\"")
set(CMAKE_EXE_LINKER_FLAGS_INIT "${CC_LINK_DIRS}")
set(CMAKE_SHARED_LINKER_FLAGS_INIT "${CC_LINK_DIRS}")
