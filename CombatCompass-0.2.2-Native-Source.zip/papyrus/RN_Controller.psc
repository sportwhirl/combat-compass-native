Scriptname RN_Controller extends Quest

; Bind these properties in the separate prototype plugin. No actor edits.
ReferenceAlias Property Destination Auto
ObjectReference Property Marker Auto
ObjectReference Property Anchor Auto
Message Property Controls Auto
Message Property ConfirmHandled Auto
Spell Property NavigatorPower Auto
Message Property Home Auto
Message Property FilterMenu Auto
Message[] Property Lists Auto
GlobalVariable[] Property Visible Auto

Bool[] handled
Int current = 0
Int[] route
Bool ready = False
Bool arrived = False
Bool paused = False
Bool menuOpen = False
Int difficultyFilter = 0
Bool walkingActive = False
String walkingKey = ""
String walkingTitle = ""
Float[] walkingPosition
Cell walkingArrivalCell
String browserToken = ""
Int browserAction = -999
Int browserPage = 0
Bool browserWindowOwned = False
Float[] browserOrigin
WorldSpace browserOriginWorld

Event OnInit()
    ; Defer until quest startup and the player's loaded scene are ready.
    RegisterForSingleUpdate(1.0)
EndEvent

Function Begin()
    If !IsRunning()
        Debug.Notification("Start RN_Controller first in the isolated test game.")
        Return
    EndIf
    If !ready
        handled = new Bool[128]
        ready = True
        current = 0
        ; Grant the power without choosing a destination for the player.
        route = new Int[1]
        current = 1
    EndIf
    Game.GetPlayer().AddSpell(NavigatorPower, False)
    paused = False
    AdvanceHandled()
    ShowDestination()
EndFunction

Function AdvanceHandled()
    While current < route.Length
        If StorageUtil.StringListHas(Self, "RNHandled", RN_WalkingBridge.RouteKey(route[current]))
            handled[route[current]] = True
        EndIf
        If !handled[route[current]]
            Return
        EndIf
        current += 1
    EndWhile
EndFunction

Function HideObjectives()
    SetObjectiveDisplayed(100, False)
    Int i = 0
    While i < RN_RouteData.StopCount()
        SetObjectiveDisplayed(10 + i, False)
        i += 1
    EndWhile
EndFunction

Function ShowDestination()
    UnregisterForUpdate()
    HideObjectives()
    Destination.Clear()
    SetActive(False)
    arrived = False
    If paused
        Return
    EndIf
    If walkingActive
        If Marker == None || Anchor == None || walkingPosition.Length != 3
            Return
        EndIf
        Marker.MoveTo(Anchor, walkingPosition[0] - Anchor.GetPositionX(), walkingPosition[1] - Anchor.GetPositionY(), walkingPosition[2] - Anchor.GetPositionZ(), False)
        Destination.ForceRefTo(Marker)
        SetObjectiveDisplayed(100, True, True)
        SetActive(True)
        Debug.Trace("[RegionalNavigator] Target " + walkingTitle + " alias=" + Destination.GetReference() + " world=" + Marker.GetWorldSpace() + " x=" + Marker.GetPositionX() + " y=" + Marker.GetPositionY() + " z=" + Marker.GetPositionZ())
        Debug.Notification("Travel to " + walkingTitle + ". Access and combat remain unverified.")
        RegisterForSingleUpdate(3.0)
        Return
    EndIf
    If current >= route.Length
        Debug.Notification("Use Regional Navigator to choose a destination.")
        Return
    EndIf
    If Marker == None || Anchor == None
        Debug.Notification("Missing destination. Stop and check plugin property bindings.")
        Return
    EndIf
    ; Move only our own persistent marker. Never move an actor or existing game ref.
    Int stop = route[current]
    Marker.MoveTo(Anchor, RN_RouteData.PositionX(stop) - Anchor.GetPositionX(), RN_RouteData.PositionY(stop) - Anchor.GetPositionY(), RN_RouteData.PositionZ(stop) - Anchor.GetPositionZ(), False)
    Destination.ForceRefTo(Marker)
    SetObjectiveDisplayed(10 + route[current], True, True)
    SetActive(True)
    RegisterForSingleUpdate(3.0)
EndFunction

Event OnUpdate()
    If !ready
        If IsRunning() && Game.GetPlayer().Is3DLoaded()
            Begin()
        Else
            RegisterForSingleUpdate(1.0)
        EndIf
        Return
    EndIf
    If !ready || paused || (!walkingActive && current >= route.Length)
        Return
    EndIf
    ObjectReference target = Marker
    If target != None
        If RN_WalkingBridge.HasArrived(target, walkingArrivalCell) && !arrived
            String destinationName = walkingTitle
            If !walkingActive
                destinationName = RN_RouteData.Title(route[current])
            EndIf
            arrived = True
            ; Suspend this destination so save/load cannot redisplay it.
            ; Keep it available for explicit completion or Skip in the power.
            paused = True
            HideObjectives()
            Destination.Clear()
            SetActive(False)
            UnregisterForUpdate()
            Debug.Notification("Arrived at " + destinationName)
            Debug.Trace("[RegionalNavigator] Arrival: hid objectives and cleared destination alias for " + destinationName)
            ; Arrival never sets handled[], completes an objective, or advances.
            Return
        EndIf
    EndIf
    RegisterForSingleUpdate(3.0)
EndEvent

Function OpenMenu()
    If menuOpen
        Return
    EndIf
    menuOpen = True
    ; Freeze the origin at power activation, before initialization or route work.
    Actor player = Game.GetPlayer()
    browserOriginWorld = player.GetWorldSpace()
    browserOrigin = new Float[3]
    browserOrigin[0] = player.GetPositionX()
    browserOrigin[1] = player.GetPositionY()
    browserOrigin[2] = player.GetPositionZ()
    Debug.Trace("[CombatCompass] Activation origin: " + browserOrigin[0] + ", " + browserOrigin[1] + ", " + browserOrigin[2])
    If !ready
        Begin()
    EndIf
    If ready
        RankedBrowser()
    EndIf
    menuOpen = False
    browserOrigin = None
    browserOriginWorld = None
EndFunction

; Included in RN_Controller by build_walking_variant.py.
; Event payload: token plus -1 close, -3 next page, -11..-13 difficulty band,
; 0..9 navigate, or 100..109 explicit Cleared.
Event OnNavigatorAction(String eventName, String strArg, Float numArg, Form sender)
    If menuOpen && browserWindowOwned && strArg == browserToken && browserAction == -999
        browserAction = numArg as Int
    EndIf
EndEvent

; SKSE scan code 1 is Escape; Flash uses a different key code (27).
Event OnKeyDown(Int keyCode)
    If keyCode == 1 && menuOpen && browserWindowOwned && UI.IsMenuOpen("CustomMenu")
        browserAction = -1
        ; Close immediately even while a helper request is pending.
        UI.CloseCustomMenu()
    EndIf
EndEvent

Function CloseNavigatorBrowser()
    UnregisterForKey(1)
    If browserWindowOwned && UI.IsMenuOpen("CustomMenu")
        UI.CloseCustomMenu()
    EndIf
    browserWindowOwned = False
    browserToken = ""
    UnregisterForModEvent("RN_NavigatorAction")
EndFunction

Bool Function RefreshWalkingResults()
    If browserOrigin == None || browserOrigin.Length != 3 || browserOriginWorld != Anchor.GetWorldSpace()
        Debug.Notification("return to road to use this power")
        Return False
    EndIf
    Int legacy = 0
    While legacy < RN_RouteData.StopCount()
        If handled[legacy]
            StorageUtil.StringListAdd(Self, "RNHandled", RN_WalkingBridge.RouteKey(legacy), False)
        EndIf
        legacy += 1
    EndWhile
    browserToken = RN_WalkingBridge.RequestAt(browserOrigin, difficultyFilter, StorageUtil.StringListToArray(Self, "RNHandled"), browserPage)
    If !RN_WalkingBridge.AwaitResponse(browserToken, browserWindowOwned)
        If browserAction != -1 && !(browserWindowOwned && !UI.IsMenuOpen("CustomMenu"))
            Debug.Notification("Native walking routes unavailable. Check Combat Compass installation.")
        EndIf
        Return False
    EndIf
    String file = "RN_Walking/response"
    String routeStatus = JsonUtil.GetPathStringValue(file, ".status")
    If routeStatus == "start_not_on_walkable_navmesh"
        Debug.Notification("return to road to use this power")
        Return False
    ElseIf routeStatus != "static_navmesh_estimate"
        Debug.Notification("Native walking search failed. Check Combat Compass installation.")
        Return False
    EndIf
    Int count = JsonUtil.PathCount(file, ".results")
    If count < 0 || count > 10 || JsonUtil.GetPathStringValue(file, ".world") != "skyrim.esm|00003C"
        Debug.Notification("Invalid walking-route response.")
        Return False
    EndIf
    If JsonUtil.GetPathIntValue(file, ".difficulty_band", -1) != difficultyFilter
        Debug.Notification("Combat Compass native response has an incompatible difficulty filter.")
        Return False
    EndIf
    If JsonUtil.GetPathIntValue(file, ".pagination") != 1
        Debug.Notification("Combat Compass native response has incompatible pagination.")
        Return False
    EndIf
    browserPage = JsonUtil.GetPathIntValue(file, ".page")
    Return True
EndFunction

Function RankedBrowser()
    If PapyrusUtil.GetVersion() <= 0 || UI.IsMenuOpen("CustomMenu")
        Return
    EndIf
    browserWindowOwned = False
    browserPage = 0
    RegisterForModEvent("RN_NavigatorAction", "OnNavigatorAction")
    Bool refresh = True
    While refresh
        browserAction = -999
        If !RefreshWalkingResults()
            CloseNavigatorBrowser()
            Return
        EndIf
        String file = "RN_Walking/response"
        Int count = JsonUtil.PathCount(file, ".results")
        If !browserWindowOwned
            UI.OpenCustomMenu("rn_encountermenu")
            browserWindowOwned = True
            RegisterForKey(1)
            Int attempt = 0
            While attempt < 80 && !UI.GetBool("CustomMenu", "_root.RN_Ready")
                Utility.WaitMenuMode(0.1)
                attempt += 1
            EndWhile
            If !UI.GetBool("CustomMenu", "_root.RN_Ready")
                Debug.Notification("Navigation interface did not load. Restart Skyrim after updating the mod.")
                CloseNavigatorBrowser()
                Return
            EndIf
        EndIf
        If !UI.IsMenuOpen("CustomMenu")
            CloseNavigatorBrowser()
            Return
        EndIf
        String[] labels = new String[10]
        Int i = 0
        While i < count
            String entry = ".results[" + i + "]"
            Int meters = (JsonUtil.GetPathFloatValue(file, entry + ".distance_units") * 0.0142875) as Int
            Int difficulty = JsonUtil.GetPathIntValue(file, entry + ".difficulty")
            String rating = "Unrated"
            If difficulty > 0
                rating = difficulty + "/10"
            EndIf
            labels[i] = JsonUtil.GetPathStringValue(file, entry + ".name") + " [" + rating + "] ~" + meters + " m"
            i += 1
        EndWhile
        UI.InvokeString("CustomMenu", "_root.RN_SetToken", browserToken)
        String bandLabel = "All difficulties"
        If difficultyFilter == 1
            bandLabel = "Difficulty 0-3"
        ElseIf difficultyFilter == 2
            bandLabel = "Difficulty 4-7"
        ElseIf difficultyFilter == 3
            bandLabel = "Difficulty 8-10"
        EndIf
        String status = bandLabel
        If count > 0
            Int firstResult = browserPage * 10 + 1
            Int lastResult = browserPage * 10 + count
            status = status + " | " + firstResult + "-" + lastResult + " of " + JsonUtil.GetPathIntValue(file, ".total_count")
        EndIf
        UI.InvokeInt("CustomMenu", "_root.RN_SetFilter", difficultyFilter)
        UI.InvokeBool("CustomMenu", "_root.RN_SetHasNext", JsonUtil.GetPathBoolValue(file, ".has_next"))
        If count == 0
            status = "return to road to use this power"
            Debug.Notification("return to road to use this power")
        EndIf
        UI.InvokeString("CustomMenu", "_root.RN_SetStatus", status)
        UI.InvokeStringA("CustomMenu", "_root.RN_SetRows", labels)
        While browserAction == -999 && UI.IsMenuOpen("CustomMenu")
            If Input.IsKeyPressed(1)
                browserAction = -1
            EndIf
            Utility.WaitMenuMode(0.1)
        EndWhile
        Int actionCode = browserAction
        If actionCode >= 100 && actionCode < 100 + count
            Int index = actionCode - 100
            String selected = ".results[" + index + "]"
            String completedKey = JsonUtil.GetPathStringValue(file, selected + ".key")
            If completedKey == ""
                CloseNavigatorBrowser()
                Return
            EndIf
            StorageUtil.StringListAdd(Self, "RNHandled", completedKey, False)
            Bool currentDone = walkingActive && walkingKey == completedKey
            If !walkingActive && current < route.Length
                currentDone = RN_WalkingBridge.RouteKey(route[current]) == completedKey
            EndIf
            If currentDone
                walkingActive = False
                walkingArrivalCell = None
                current = route.Length
                paused = True
                HideObjectives()
                Destination.Clear()
                SetActive(False)
                UnregisterForUpdate()
            EndIf
            Debug.Trace("[RegionalNavigator] Explicit Cleared: " + completedKey)
            ; The open menu remains busy until fresh results replace its rows.
        ElseIf actionCode >= 0 && actionCode < count
            String selected = ".results[" + actionCode + "]"
            String selectedKey = JsonUtil.GetPathStringValue(file, selected + ".key")
            CloseNavigatorBrowser()
            If selectedKey != "" && !StorageUtil.StringListHas(Self, "RNHandled", selectedKey)
                walkingKey = selectedKey
                walkingTitle = JsonUtil.GetPathStringValue(file, selected + ".name")
                walkingPosition = JsonUtil.PathFloatElements(file, selected + ".position")
                If walkingPosition.Length != 3
                    Return
                EndIf
                walkingArrivalCell = None
                String cellPlugin = JsonUtil.GetPathStringValue(file, selected + ".arrival_cell_plugin")
                Int cellId = JsonUtil.GetPathIntValue(file, selected + ".arrival_cell_id")
                If cellPlugin != "" && cellId > 0
                    walkingArrivalCell = Game.GetFormFromFile(cellId, cellPlugin) as Cell
                EndIf
                walkingActive = True
                paused = False
                ShowDestination()
            EndIf
            Return
        ElseIf actionCode == -3
            If JsonUtil.GetPathBoolValue(file, ".has_next")
                browserPage += 1
            EndIf
        ElseIf actionCode <= -11 && actionCode >= -13
            Int chosenBand = -actionCode - 10
            If difficultyFilter == chosenBand
                difficultyFilter = 0
            Else
                difficultyFilter = chosenBand
            EndIf
            browserPage = 0
            ; Refresh inside the same window. Re-click the active band for all.
        Else
            CloseNavigatorBrowser()
            refresh = False
        EndIf
    EndWhile
EndFunction

Bool Function BrowserOptions()
    Int choice = Home.Show()
    If choice >= 0 && choice <= 3
        difficultyFilter = choice
        Return True
    ElseIf choice == 4
        RouteControls()
    EndIf
    Return False
EndFunction

Function RouteControls()
        Int choice = Controls.Show()
        If walkingActive
            If choice == 0
                If ConfirmHandled.Show() == 0
                    StorageUtil.StringListAdd(Self, "RNHandled", walkingKey, False)
                    walkingActive = False
                    current = route.Length
                    ShowDestination()
                EndIf
            ElseIf choice == 1
                ; Skip does not add to the shared handled ledger.
                walkingActive = False
                current = route.Length
                ShowDestination()
            ElseIf choice == 2
                paused = False
                ShowDestination()
            ElseIf choice == 3
                paused = !paused
                ShowDestination()
            ElseIf choice == 4
                ChooseRoute(0)
            EndIf
            Return
        EndIf
        If choice == 0
            If current < route.Length && ConfirmHandled.Show() == 0
                handled[route[current]] = True
                StorageUtil.StringListAdd(Self, "RNHandled", RN_WalkingBridge.RouteKey(route[current]), False)
                ; Explicit player report; no claim of engine-verified combat clear.
                current += 1
                AdvanceHandled()
                ShowDestination()
            EndIf
        ElseIf choice == 1
            If current < route.Length
                current += 1
                AdvanceHandled()
                ShowDestination()
            EndIf
        ElseIf choice == 2
            ; Revisit skipped stops. Shared handled table is retained.
            current = 0
            paused = False
            AdvanceHandled()
            ShowDestination()
        ElseIf choice == 3
            paused = !paused
            ShowDestination()
        ElseIf choice == 4
            ChooseRoute(0)
        EndIf
EndFunction

Function ResumeAfterLoad()
    ; Menu lock and activation snapshot must not survive loading a save.
    menuOpen = False
    browserOrigin = None
    browserOriginWorld = None
    If ready
        Game.GetPlayer().AddSpell(NavigatorPower, False)
        ShowDestination()
    Else
        RegisterForSingleUpdate(1.0)
    EndIf
EndFunction

Function ChooseRoute(Int routeId)
    If routeId != 0
        Debug.Notification("This region is still pending encounter validation.")
        Return
    EndIf
    If !ready
        Begin()
    EndIf
    walkingActive = False
    walkingArrivalCell = None
    route = RN_RouteData.RouteStops(routeId)
    current = 0
    paused = False
    AdvanceHandled()
    ShowDestination()
EndFunction
