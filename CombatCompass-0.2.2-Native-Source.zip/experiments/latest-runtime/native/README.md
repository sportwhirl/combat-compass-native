# Combat Compass native 0.2.2 beta

Targets Steam Skyrim 1.7.104 and 1.6.1170 with maintained CommonLibSSE-NG
12.1.0 and Address Library format 5/legacy format 2 support.
Routing, catalog, Papyrus API and UI behavior are retained from accepted test10.
Build from the source bundle root with
bash experiments/latest-runtime/build_windows.sh.
See README-BUILD.txt in the matching native-source archive for dependencies.
The combined native DLL uses GPL-3.0-or-later with included CommonLib exceptions.
Automated build/loader/address/provider checks passed. Native startup and the
requested power/menu, filters and Next10 gameplay checks on actual1.7.104
passed; the user accepted the result. Prior detailed arrival/Cleared/save-reload
acceptance belongs to0.2.1 on1.6.1170.
