#pragma once
#include "Routing.hpp"
#include <atomic>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <thread>

namespace cc {
// One worker, one replaceable pending request, one current response.
// No RE/SKSE/game objects are captured by the worker.
class Service {
public:
    using Loader=std::function<Router()>;
    explicit Service(Loader loader);
    ~Service();
    Service(const Service&)=delete;
    Service& operator=(const Service&)=delete;
    bool submit(Request request);
    void reset();
    std::optional<Response> response(const std::string& token) const;
private:
    struct Job { std::uint64_t generation; Request request; };
    void run();
    Loader loader_;
    mutable std::mutex mutex_;
    std::condition_variable wake_;
    std::optional<Job> pending_;
    std::optional<Response> result_;
    std::atomic<std::uint64_t> generation_{0};
    std::atomic<bool> stopping_{false};
    std::thread worker_;
};
}
