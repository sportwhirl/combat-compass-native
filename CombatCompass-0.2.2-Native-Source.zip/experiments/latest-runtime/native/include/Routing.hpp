#pragma once
#include <array>
#include <cstdint>
#include <functional>
#include <istream>
#include <map>
#include <optional>
#include <queue>
#include <set>
#include <string>
#include <vector>

namespace cc {
struct Vec { double x{}, y{}, z{}; };
double distance(Vec a, Vec b);
struct Node {
    bool valid{};
    std::int32_t cellX{}, cellY{};
    std::array<Vec, 3> triangle{};
    Vec center{};
    std::array<std::int32_t, 3> adjacent{-1,-1,-1};
    std::array<double, 3> costs{};
};
struct Target {
    std::string key, name, reference, arrivalPlugin;
    std::uint32_t arrivalID{};
    int difficulty{};
    Vec position{}, projected{};
    std::int32_t node{-1};
};
struct Location { std::uint32_t node{}; Vec point{}; };
struct Request {
    std::string token;
    Vec position;
    int band{}, page{};
    std::set<std::string> cleared;
};
struct Row { Target target; double units{}, score{}; };
struct Response {
    std::string token, status;
    int band{}, page{};
    std::size_t total{}, visited{};
    bool hasNext{};
    double connector{};
    std::vector<Row> rows;
    std::string resultsJSON() const;
};
struct Cancelled {};
// Single-owner engine: the async service serializes access, never game threads.
class Router {
public:
    std::vector<Node> nodes;
    std::vector<Target> targets;
    static Router read(std::istream&);
    void prepare();
    void write(std::ostream&) const;
    std::optional<Location> locate(Vec point, bool connector = false, double maxHeight = 512) const;
    Response search(const Request&, const std::function<bool()>& cancelled = {});
private:
    std::map<std::pair<int,int>, std::vector<std::uint32_t>> cells_;
    std::int64_t start_{-1};
    std::vector<double> best_;
    std::vector<bool> settled_;
    using Entry = std::pair<double,std::uint32_t>;
    std::priority_queue<Entry, std::vector<Entry>, std::greater<Entry>> queue_;
};
}
