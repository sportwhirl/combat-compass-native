#pragma once
#include "Routing.hpp"
#include <filesystem>
#include <span>
namespace cc {
struct PluginSource {std::string name;std::filesystem::path path;};
struct CatalogEntry {std::string key,name,reference,kind;int difficulty{};};
struct BuildReport {
    std::size_t plugins{},meshes{},nodes{},eligibleTargets{},unmappedTargets{},skippedRecords{};
    bool cacheHit{};
    std::string fingerprint;
};
std::vector<CatalogEntry> readCatalog(const std::filesystem::path&);
std::string sha256(std::span<const unsigned char>);
Router buildGameData(const std::vector<PluginSource>&,const std::filesystem::path& catalog,
                     const std::filesystem::path& cache,BuildReport&);
}
