#include "GameData.hpp"
#include <iomanip>
#include <sstream>
#include <stdexcept>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>
#include <bcrypt.h>
#else
#include <openssl/evp.h>
#endif
namespace cc {
std::string sha256(std::span<const unsigned char> input) {
    unsigned char digest[32]{};
#ifdef _WIN32
    BCRYPT_ALG_HANDLE alg=nullptr;BCRYPT_HASH_HANDLE hash=nullptr;
    if(BCryptOpenAlgorithmProvider(&alg,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)
        throw std::runtime_error("SHA256 provider unavailable");
    DWORD size=0,read=0;
    auto status=BCryptGetProperty(alg,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&size),sizeof(size),&read,0);
    std::vector<unsigned char> object(size);
    if(status>=0)status=BCryptCreateHash(alg,&hash,object.data(),size,nullptr,0,0);
    for(std::size_t at=0;status>=0&&at<input.size();) {
        auto n=static_cast<ULONG>(std::min<std::size_t>(input.size()-at,1u<<24));
        status=BCryptHashData(hash,const_cast<PUCHAR>(input.data()+at),n,0);at+=n;
    }
    if(status>=0)status=BCryptFinishHash(hash,digest,sizeof(digest),0);
    if(hash)BCryptDestroyHash(hash);
    BCryptCloseAlgorithmProvider(alg,0);
    if(status<0)throw std::runtime_error("SHA256 failed");
#else
    unsigned int size=0;
    if(EVP_Digest(input.data(),input.size(),digest,&size,EVP_sha256(),nullptr)!=1||size!=32)
        throw std::runtime_error("SHA256 failed");
#endif
    std::ostringstream s;
    for(auto b:digest)s<<std::hex<<std::setw(2)<<std::setfill('0')<<unsigned(b);
    return s.str();
}
}
