#include "GameData.hpp"
#include <algorithm>
#include <bit>
#include <cmath>
#include <chrono>
#include <random>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <unordered_map>
#include <zlib.h>
namespace cc {
namespace {
using Bytes=std::vector<unsigned char>;
using View=std::span<const unsigned char>;
struct Cursor {
    View b;std::size_t p{};
    View take(std::size_t n) {
        if(n>b.size()-p)throw std::runtime_error("Truncated plugin data: offset "+std::to_string(p)+" requested "+std::to_string(n)+" of "+std::to_string(b.size()));
        auto out=b.subspan(p,n);p+=n;return out;
    }
    std::uint32_t u32(){auto x=take(4);return x[0]|(std::uint32_t(x[1])<<8)|(std::uint32_t(x[2])<<16)|(std::uint32_t(x[3])<<24);}
    std::uint16_t u16(){auto x=take(2);return std::uint16_t(x[0]|(x[1]<<8));}
    int i16(){return std::bit_cast<std::int16_t>(u16());}
    double f32(){auto v=std::bit_cast<float>(u32());if(!std::isfinite(v))throw std::runtime_error("Nonfinite geometry");return v;}
    Vec vec(){auto x=f32(),y=f32(),z=f32();return{x,y,z};}
};
std::string lower(std::string s){for(char& c:s)if(c>='A'&&c<='Z')c+=32;return s;}
std::string string(View v){return std::string(reinterpret_cast<const char*>(v.data()),v.size());}
std::string zstring(View v){auto s=string(v);auto n=s.find('\0');if(n!=s.npos)s.resize(n);return s;}
bool filename(const std::string& s) {
    return !s.empty()&&s.size()<260&&s.find_first_of("/\\:\r\n\t")==s.npos&&s!="."&&s!="..";
}
Bytes readFile(const std::filesystem::path& path) {
    auto n=std::filesystem::file_size(path);
    if(n>2ull*1024*1024*1024)throw std::runtime_error("Plugin file exceeds 2 GiB reader limit");
    Bytes b(static_cast<std::size_t>(n));std::ifstream f(path,std::ios::binary);
    f.read(reinterpret_cast<char*>(b.data()),b.size());
    if(!f)throw std::runtime_error("Cannot read input file: "+path.string());
    return b;
}
std::map<std::string,View> fields(View b) {
    Cursor c{b};std::map<std::string,View> out;std::optional<std::uint32_t> extended;
    while(c.p<c.b.size()) {
        auto sig=string(c.take(4));std::uint32_t size=c.u16();
        if(sig=="XXXX") {
            if(size!=4||extended)throw std::runtime_error("Invalid extended subrecord");
            extended=c.u32();continue;
        }
        if(extended){size=*extended;extended.reset();}
        auto value=c.take(size);out.try_emplace(sig,value);
    }
    if(extended)throw std::runtime_error("Dangling extended subrecord");
    return out;
}
struct Triangle {std::array<int,3> vertices,edges;std::uint16_t flags;};
struct Mesh {
    std::string key;std::uint64_t order{};std::size_t offset{};int x{},y{};
    std::vector<Vec> vertices;std::vector<Triangle> triangles;
    std::vector<std::pair<std::string,int>> links;
};
struct Ref {
    std::string cell,world,partner,base,editor,enableParent;
    std::uint32_t enableFlags{};
    bool initiallyDisabled{},deleted{},scripted{},parentControlled{},unavailableWithoutParent{};
    std::optional<Vec> position,arrival;
    bool unavailable{},locked{},door{};
};
struct Cell {std::string world;bool interior{},deleted{};};
struct Reader {
    std::unordered_map<std::string,Mesh> meshes;
    std::unordered_map<std::string,Ref> refs;
    std::unordered_map<std::string,Cell> cells;
    std::set<std::string> wanted;
    std::vector<std::string> masters;
    std::string plugin,lastRecord;
    std::uint64_t sequence{};
    BuildReport& report;
    explicit Reader(BuildReport& r):report(r){}
    std::string key(std::uint32_t fid) {
        if(!fid)return "";
        auto index=fid>>24;
        if(index>masters.size())throw std::runtime_error("Invalid record master index in "+plugin);
        std::ostringstream s;s<<(index==masters.size()?plugin:masters[index])<<'|'<<std::uppercase<<std::hex<<std::setw(6)<<std::setfill('0')<<(fid&0xffffff);
        return s.str();
    }
    std::string link(View v) {if(v.size()<4)return "";Cursor c{v};return key(c.u32());}
    Mesh mesh(View data,const std::string& id) {
        Cursor c{data};if(c.u32()!=12)throw std::runtime_error("Unsupported NAVM version");
        c.u32();auto world=key(c.u32());
        if(world!="skyrim.esm|00003C")throw std::runtime_error("Unexpected NAVM world");
        Mesh m;m.key=id;m.order=sequence++;m.y=c.i16();m.x=c.i16();
        auto n=c.u32();if(n>1000000)throw std::runtime_error("Too many vertices");
        for(std::uint32_t i=0;i<n;++i)m.vertices.push_back(c.vec());
        n=c.u32();if(n>32768)throw std::runtime_error("Too many triangles");
        for(std::uint32_t i=0;i<n;++i) {
            Triangle t;
            for(auto& v:t.vertices)v=c.i16();
            for(auto& e:t.edges)e=c.i16();
            t.flags=c.u16();c.u16();
            if(!(t.flags&8))for(auto v:t.vertices)if(v<0||std::size_t(v)>=m.vertices.size())throw std::runtime_error("Invalid NAVM vertex index");
            m.triangles.push_back(t);
        }
        n=c.u32();if(n>1000000)throw std::runtime_error("Too many NAVM links");
        for(std::uint32_t i=0;i<n;++i){c.u32();auto k=key(c.u32());auto t=c.i16();m.links.emplace_back(k,t);}
        return m;
    }
    void scan(View data,std::string world="",std::string cell="",int depth=0) {
        if(depth>32)throw std::runtime_error("Plugin group nesting exceeded");
        Cursor c{data};
        while(c.p<data.size()) {
            auto sig=string(c.take(4));auto size=c.u32(),flags=c.u32(),fid=c.u32();c.take(8);
            if(sig=="GRUP") {
                if(size<24)throw std::runtime_error("Invalid group length");
                auto child=c.take(size-24);auto w=world,ce=cell;
                if(fid==1)w=key(flags);
                if(fid==6||fid==8||fid==9||fid==10)ce=key(flags);
                scan(child,w,ce,depth+1);continue;
            }
            lastRecord=sig+" "+std::to_string(fid);
            auto raw=c.take(size);
            if(sig!="TES4"&&sig!="NAVM"&&sig!="CELL"&&sig!="REFR"&&sig!="ACHR")continue;
            std::string id;
            try {id=key(fid);}catch(const std::runtime_error&) {
                // Match known malformed unrelated references; never skip navmeshes.
                if(sig=="REFR"||sig=="ACHR"){++report.skippedRecords;continue;}throw;
            }
            Bytes inflated;
            if(flags&0x40000) {
                Cursor z{raw};auto expected=z.u32();
                if(expected>64*1024*1024)throw std::runtime_error("Compressed record too large");
                inflated.resize(expected);uLongf actual=expected;
                if(uncompress(inflated.data(),&actual,raw.data()+4,raw.size()-4)!=Z_OK||actual!=expected)
                    throw std::runtime_error("Invalid compressed plugin record");
                raw=inflated;
            }
            // TES4 repeats MAST; do not collapse it through fields().
            if(sig=="TES4") {
                Cursor t{raw};masters.clear();std::optional<std::uint32_t> extended;
                while(t.p<raw.size()){
                    auto tag=string(t.take(4));auto n=t.u16();
                    if(tag=="XXXX"){if(n!=4||extended)throw std::runtime_error("Invalid TES4 XXXX");extended=t.u32();continue;}
                    auto v=t.take(extended.value_or(n));extended.reset();
                    if(tag=="MAST"){auto master=lower(zstring(v));if(!filename(master))throw std::runtime_error("Bad master name");masters.push_back(master);}
                }
                if(extended)throw std::runtime_error("Dangling TES4 XXXX");
                continue;
            }
            auto f=fields(raw);
            if(sig=="NAVM") {
                auto nv=f["NVNM"];
                if(flags&0x20 || nv.size()<12){meshes.erase(id);continue;}
                if(link(nv.subspan(8,4))!="skyrim.esm|00003C"){meshes.erase(id);continue;}
                meshes[id]=mesh(nv,id);
            } else if(sig=="CELL") {
                auto d=f["DATA"];
                cells[id]={world,!d.empty()&&bool(d[0]&1),bool(flags&0x20)};
            } else {
                auto xtel=f["XTEL"];
                if(!wanted.contains(id)&&xtel.empty()&&!refs.contains(id))continue;
                Ref r;r.cell=cell;r.world=world;r.unavailable=bool(flags&(0x20|0x800))||!f["XESP"].empty();
                if(sig=="ACHR"&&(flags&0x200))r.unavailable=true; // starts dead
                r.initiallyDisabled=bool(flags&0x800);r.deleted=bool(flags&0x20);r.scripted=!f["VMAD"].empty();
                r.unavailableWithoutParent=bool(flags&(0x20|0x800))||bool(sig=="ACHR"&&(flags&0x200));
                r.base=link(f["NAME"]);r.editor=f["EDID"].empty()?"":zstring(f["EDID"]);
                auto parent=f["XESP"];r.parentControlled=!parent.empty();
                if(parent.size()==8){Cursor e{parent};r.enableParent=key(e.u32());r.enableFlags=e.u32();}
                r.locked=!f["XLOC"].empty();r.partner=link(xtel);r.door=!xtel.empty();
                if(f["DATA"].size()==24){Cursor d{f["DATA"]};r.position=d.vec();}
                if(xtel.size()>=28){Cursor d{xtel.subspan(4)};r.arrival=d.vec();}
                refs[id]=r;
            }
        }
    }
};
std::vector<std::string> split(const std::string& line) {
    std::vector<std::string> out;std::istringstream s(line);std::string v;
    while(std::getline(s,v,'\t'))out.push_back(v);
    return out;
}
Vec mid(Vec a,Vec b){return{(a.x+b.x)/2,(a.y+b.y)/2,(a.z+b.z)/2};}
// Only the evidenced original BFB front door is exempted from the generic
// conditional-reference exclusion. This reads authored initial state; it does
// not infer live save/quest state or permit arbitrary enable-parent chains.
bool defaultEnabledBfbDoor(const std::string& id,const Ref& ref,const Reader& reader) {
    if(id!="skyrim.esm|015DA5"||!ref.door||ref.unavailableWithoutParent||ref.scripted||
       ref.enableParent!="skyrim.esm|093638"||ref.enableFlags!=1)return false;
    auto p=reader.refs.find(ref.enableParent);
    if(p==reader.refs.end())return false;
    const auto& parent=p->second;
    return parent.editor=="E3demoMarker"&&parent.base=="skyrim.esm|00003B"&&
           parent.initiallyDisabled&&!parent.deleted&&!parent.scripted&&!parent.parentControlled;
}
Router assemble(Reader& reader,const std::vector<CatalogEntry>& catalog) {
    Router router;std::vector<Mesh*> ordered;
    for(auto& [k,m]:reader.meshes)ordered.push_back(&m);
    std::sort(ordered.begin(),ordered.end(),[](auto a,auto b){return a->order<b->order;});
    for(auto m:ordered) {
        m->offset=router.nodes.size();
        for(auto& t:m->triangles) {
            Node n;n.valid=!(t.flags&(8|512));n.cellX=m->x;n.cellY=m->y;
            if(n.valid)for(int i=0;i<3;++i)n.triangle[i]=m->vertices[t.vertices[i]];
            // Python graph stores centers/costs in float32 arrays.
            n.center={float((n.triangle[0].x+n.triangle[1].x+n.triangle[2].x)/3),
                      float((n.triangle[0].y+n.triangle[1].y+n.triangle[2].y)/3),
                      float((n.triangle[0].z+n.triangle[1].z+n.triangle[2].z)/3)};
            router.nodes.push_back(n);
        }
    }
    for(auto m:ordered) for(std::size_t ti=0;ti<m->triangles.size();++ti) {
        auto& t=m->triangles[ti];auto& node=router.nodes[m->offset+ti];if(!node.valid)continue;
        for(int edge=0;edge<3;++edge) {
            int index=t.edges[edge];if(index<0)continue;
            Mesh* other=m;
            if(t.flags&(1<<edge)) {
                if(std::size_t(index)>=m->links.size())continue;
                auto& link=m->links[index];auto found=reader.meshes.find(link.first);
                if(found==reader.meshes.end())continue;
                other=&found->second;index=link.second;
            }
            if(index<0||std::size_t(index)>=other->triangles.size())continue;
            auto dest=other->offset+index;auto& next=router.nodes[dest];if(!next.valid)continue;
            Vec a=node.triangle[edge],b=node.triangle[(edge+1)%3];
            double gap=17;int partner=-1;
            for(int j=0;j<3;++j){
                auto c=next.triangle[j],d=next.triangle[(j+1)%3];
                double g=std::min(std::max(distance(a,c),distance(b,d)),std::max(distance(a,d),distance(b,c)));
                if(g<=16&&g<gap){gap=g;partner=j;}
            }
            if(partner<0)continue;
            auto portal=mid(a,b),exit=mid(next.triangle[partner],next.triangle[(partner+1)%3]);
            node.adjacent[edge]=static_cast<std::int32_t>(dest);
            node.costs[edge]=float(distance(node.center,portal)+distance(portal,exit)+distance(exit,next.center));
        }
    }
    std::vector<std::pair<std::size_t,int>> rejected;
    for(std::size_t i=0;i<router.nodes.size();++i)for(int e=0;e<3;++e) {
        int dest=router.nodes[i].adjacent[e];if(dest<0)continue;
        auto& adjacent=router.nodes[dest].adjacent;
        if(std::find(adjacent.begin(),adjacent.end(),int(i))==adjacent.end())rejected.emplace_back(i,e);
    }
    for(auto [i,e]:rejected)router.nodes[i].adjacent[e]=-1;
    router.prepare();
    for(auto& c:catalog) {
        auto found=reader.refs.find(c.reference);
        if(found==reader.refs.end()){++reader.report.unmappedTargets;continue;}
        auto& ref=found->second;auto world=ref.world;
        if(world.empty())world=reader.cells[ref.cell].world;
        if((ref.unavailable&&!defaultEnabledBfbDoor(c.reference,ref,reader))||ref.locked||!ref.position||world!="skyrim.esm|00003C"){++reader.report.unmappedTargets;continue;}
        Target t;t.key=c.key;t.name=c.name;t.reference=c.reference;t.difficulty=c.difficulty;t.position=*ref.position;
        if(c.kind=="door") {
            auto partner=reader.refs.find(ref.partner);
            if(partner==reader.refs.end()||partner->second.unavailable||partner->second.partner!=c.reference){++reader.report.unmappedTargets;continue;}
            auto& p=partner->second;auto cell=reader.cells.find(p.cell);
            if(cell==reader.cells.end()||cell->second.deleted||!cell->second.interior){++reader.report.unmappedTargets;continue;}
            if(p.arrival)t.position=*p.arrival;
            auto bar=p.cell.rfind('|');t.arrivalPlugin=p.cell.substr(0,bar);t.arrivalID=std::stoul(p.cell.substr(bar+1),nullptr,16);
        } else if(c.kind=="wildlife"&&!router.locate(t.position)) {
            auto loc=router.locate(t.position,true,1024);
            if(!loc){++reader.report.unmappedTargets;continue;}
            t.position=loc->point;
        }
        router.targets.push_back(std::move(t));
    }
    router.prepare();
    reader.report.meshes=ordered.size();reader.report.nodes=router.nodes.size();
    reader.report.eligibleTargets=router.targets.size();
    return router;
}
}
static std::vector<CatalogEntry> parseCatalog(const std::string& contents) {
    std::istringstream in(contents);std::string line;std::vector<CatalogEntry> out;std::set<std::string> keys;
    if(!std::getline(in,line)||line!="CCCATALOG1")throw std::runtime_error("Invalid authored catalog");
    while(std::getline(in,line)) {
        if(!line.empty()&&line.back()=='\r')line.pop_back();
        if(line.empty())continue;
        auto v=split(line);if(v.size()!=5)throw std::runtime_error("Bad catalog row");
        int rating=std::stoi(v[2]);
        if(rating<0||rating>10||!keys.insert(v[0]).second||
           (v[4]!="door"&&v[4]!="reference"&&v[4]!="wildlife"))throw std::runtime_error("Invalid catalog value");
        out.push_back({v[0],v[1],v[3],v[4],rating});
        if(out.size()>10000)throw std::runtime_error("Oversized catalog");
    }
    return out;
}
std::vector<CatalogEntry> readCatalog(const std::filesystem::path& path) {
    return parseCatalog(string(readFile(path)));
}
Router buildGameData(const std::vector<PluginSource>& sources,const std::filesystem::path& catalog,
                     const std::filesystem::path& cache,BuildReport& report) {
    // Cache identity includes ordered plugin names and SHA256 of every byte,
    // catalog contents and an explicit reader/graph schema version.
    std::string identity="CombatCompass-native-reader-2-bfb-default-parent\n";
    std::vector<std::string> hashes;std::set<std::string> names;
    for(auto& source:sources) {
        auto name=lower(source.name);
        if(!filename(name)||!names.insert(name).second)throw std::runtime_error("Invalid/duplicate plugin name");
        auto hash=sha256(readFile(source.path));hashes.push_back(hash);identity+=name+":"+hash+"\n";
    }
    auto catalogBytes=readFile(catalog);
    identity+=sha256(catalogBytes);
    report.fingerprint=sha256(View(reinterpret_cast<const unsigned char*>(identity.data()),identity.size()));
    auto entries=parseCatalog(string(catalogBytes));report.plugins=sources.size();
    auto cached=cache/(report.fingerprint+".ccg");
    if(!cache.empty()&&std::filesystem::exists(cached)) {
        try{
            auto bytes=readFile(cached);
            if(bytes.size()<64)throw std::runtime_error("Truncated cache");
            View payload(bytes.data(),bytes.size()-64);
            if(sha256(payload)!=string(View(bytes).last(64)))throw std::runtime_error("Cache checksum mismatch");
            std::istringstream in(string(payload),std::ios::binary);auto router=Router::read(in);
            report.cacheHit=true;report.nodes=router.nodes.size();report.eligibleTargets=router.targets.size();
            return router;
        }catch(const std::exception&){/* Corrupt caches rebuild from plugins. */}
    }
    Reader reader(report);
    reader.wanted.insert("skyrim.esm|093638"); // BFB default-state evidence; not a target.
    for(auto& entry:entries)reader.wanted.insert(entry.reference);
    std::set<std::string> seen;
    for(std::size_t i=0;i<sources.size();++i) {
        auto data=readFile(sources[i].path);
        if(sha256(data)!=hashes[i])throw std::runtime_error("Plugin changed during graph build");
        reader.plugin=lower(sources[i].name);reader.masters.clear();
        try {reader.scan(data);}catch(const std::exception& e){throw std::runtime_error(reader.plugin+" ["+reader.lastRecord+"]: "+e.what());}
        for(auto& master:reader.masters)if(!seen.contains(master))throw std::runtime_error("Missing or out-of-order master: "+master);
        seen.insert(reader.plugin);
    }
    auto router=assemble(reader,entries);
    if(!cache.empty()) {
        // Failure to save a cache must not disable a valid in-memory graph.
        try {
            std::filesystem::create_directories(cache);auto temp=cached;
            temp+="."+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count())+
                  "."+std::to_string(std::random_device{}())+".tmp";
            std::ostringstream data(std::ios::binary);router.write(data);auto bytes=data.str();
            auto digest=sha256(View(reinterpret_cast<const unsigned char*>(bytes.data()),bytes.size()));
            {std::ofstream out(temp,std::ios::binary|std::ios::trunc);out.write(bytes.data(),bytes.size());out<<digest;if(!out)throw std::runtime_error("Cache write failed");}
            std::filesystem::remove(cached);std::filesystem::rename(temp,cached);
        }catch(const std::exception&){}
    }
    return router;
}
}
