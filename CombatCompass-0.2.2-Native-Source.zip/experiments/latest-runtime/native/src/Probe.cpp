// Offline verification executable. NOT the shipped runtime.
#include "Routing.hpp"
#include <fstream>
#include <iostream>
#include <sstream>
int main(int argc,char** argv) {
    try {
        if(argc!=2)throw std::runtime_error("Usage: routing-probe DATASET (requests on stdin)");
        std::ifstream input(argv[1],std::ios::binary);auto router=cc::Router::read(input);
        std::string line;
        while(std::getline(std::cin,line)) {
            std::istringstream s(line);cc::Request q; s>>q.token>>q.position.x>>q.position.y>>q.position.z>>q.band>>q.page;
            if(!s)throw std::runtime_error("Bad probe request");
            // Cleared keys after a tab, one per tab (keys may contain spaces).
            std::string rest;std::getline(s,rest);std::istringstream keys(rest);
            while(std::getline(keys,rest,'\t'))if(!rest.empty())q.cleared.insert(rest);
            auto r=router.search(q);
            std::cout<<"{\"status\":\""<<r.status<<"\",\"page\":"<<r.page<<",\"total_count\":"<<r.total
                <<",\"has_next\":"<<(r.hasNext?"true":"false")<<",\"visited\":"<<r.visited
                <<",\"results\":"<<r.resultsJSON()<<"}"<<std::endl;
        }
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
