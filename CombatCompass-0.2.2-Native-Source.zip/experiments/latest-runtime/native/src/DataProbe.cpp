#include "GameData.hpp"
#include <fstream>
#include <iostream>
#include <sstream>
int main(int argc,char** argv) {
    try {
        if(argc!=4)throw std::runtime_error("Usage: data-probe INPUTS_TSV CATALOG_TSV CACHE_DIR");
        std::ifstream in(argv[1]);std::string line;std::vector<cc::PluginSource> sources;
        while(std::getline(in,line)){
            auto tab=line.find('\t');if(tab==line.npos)throw std::runtime_error("Invalid input manifest");
            sources.push_back({line.substr(0,tab),line.substr(tab+1)});
        }
        cc::BuildReport report;
        auto router=cc::buildGameData(sources,argv[2],argv[3],report);
        std::cerr<<"plugins="<<report.plugins<<" meshes="<<report.meshes<<" nodes="<<report.nodes
                 <<" targets="<<report.eligibleTargets<<" cache_hit="<<report.cacheHit
                 <<" skipped_records="<<report.skippedRecords<<" fingerprint="<<report.fingerprint<<'\n';
        while(std::getline(std::cin,line)) {
            std::istringstream s(line);cc::Request q;s>>q.token>>q.position.x>>q.position.y>>q.position.z>>q.band>>q.page;
            if(!s)throw std::runtime_error("Invalid query");
            std::string rest;std::getline(s,rest);std::istringstream keys(rest);
            while(std::getline(keys,rest,'\t'))if(!rest.empty())q.cleared.insert(rest);
            auto r=router.search(q);
            std::cout<<"{\"status\":\""<<r.status<<"\",\"total\":"<<r.total<<",\"page\":"<<r.page
                     <<",\"results\":"<<r.resultsJSON()<<"}"<<std::endl;
        }
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
