// Native load-order graph provider. Game integration remains a test candidate.
#include <SKSE/SKSE.h>
#include <RE/N/NativeFunction.h>
#include <RE/P/PackUnpackImpl.h>
#include "Service.hpp"
#include "GameData.hpp"
#include <RE/T/TESDataHandler.h>
#include <RE/T/TESFile.h>
#include <atomic>
#include <unordered_set>
#include <fstream>
#include <memory>
#include <stdexcept>

namespace {
// SKSE plugins live for the process lifetime. Do not join a worker from a static
// destructor under the Windows DLL loader lock during process termination.
std::atomic<cc::Service*> service{nullptr};
std::filesystem::path stateDirectory() {
    wchar_t path[32768]{};
    auto n=REX::W32::GetEnvironmentVariableW(L"LOCALAPPDATA",path,32768);
    if(!n||n>=32768)throw std::runtime_error("LOCALAPPDATA unavailable");
    return std::filesystem::path(path)/"CombatCompassNative";
}
std::vector<cc::PluginSource> activePlugins() {
    auto data=RE::TESDataHandler::GetSingleton();
    if(!data)throw std::runtime_error("TESDataHandler unavailable");
    std::unordered_set<RE::TESFile*> active;
    for(std::uint32_t i=0;i<data->GetLoadedModCount();++i)active.insert(data->GetLoadedMods()[i]);
    for(std::uint32_t i=0;i<data->GetLoadedLightModCount();++i)active.insert(data->GetLoadedLightMods()[i]);
    std::vector<cc::PluginSource> out;
    // Preserve the ordered engine file list, including interleaved light plugins.
    // Filtering by loaded-file membership avoids inactive plugins in this list.
    for(auto file:data->files) {
        if(file&&active.erase(file)) {
            auto name=std::string(file->GetFilename());
            out.push_back({name,std::filesystem::path("Data")/name});
        }
    }
    if(!active.empty()||out.empty())throw std::runtime_error("Incomplete active plugin list");
    return out;
}
void initializeProvider() {
    if(service.load())return;
    auto inputs=activePlugins();auto directory=stateDirectory();
    std::filesystem::create_directories(directory);
    std::ofstream order(directory/"active-load-order.txt");
    for(auto& input:inputs)order<<input.name<<'\n';
    service.store(new cc::Service([inputs=std::move(inputs),directory] {
        std::ofstream log(directory/"graph-build.log");
        try {
            cc::BuildReport report;
            auto router=cc::buildGameData(inputs,"Data/SKSE/Plugins/CombatCompass/destinations.tsv",directory/"cache",report);
            log<<"fingerprint="<<report.fingerprint<<" cache_hit="<<report.cacheHit
               <<" plugins="<<report.plugins<<" meshes="<<report.meshes<<" nodes="<<report.nodes
               <<" eligible_targets="<<report.eligibleTargets<<" skipped_records="<<report.skippedRecords<<'\n';
            return router;
        }catch(const std::exception& e){log<<"ERROR: "<<e.what()<<'\n';throw;}
    }));
}
std::optional<cc::Response> result(RE::BSFixedString token) {
    auto current=service.load();
    return current ? current->response(token.c_str()) : std::nullopt;
}
std::int32_t Version(RE::StaticFunctionTag*) { return 1; }
bool Submit(RE::StaticFunctionTag*,RE::BSFixedString token,std::vector<float> position,
            std::int32_t band,std::int32_t page,std::vector<RE::BSFixedString> cleared) {
    auto current=service.load();
    if(!current||position.size()!=3||cleared.size()>10000)return false;
    cc::Request request{token.c_str(),{position[0],position[1],position[2]},band,page,{}};
    for(auto& key:cleared)request.cleared.insert(key.c_str());
    return current->submit(std::move(request));
}
bool Ready(RE::StaticFunctionTag*,RE::BSFixedString token) {return result(token).has_value();}
std::string Status(RE::StaticFunctionTag*,RE::BSFixedString token) {
    auto r=result(token);return r?r->status:"";
}
std::string Results(RE::StaticFunctionTag*,RE::BSFixedString token) {
    auto r=result(token);return r?r->resultsJSON():"[]";
}
std::int32_t Page(RE::StaticFunctionTag*,RE::BSFixedString token) {
    auto r=result(token);return r?r->page:0;
}
std::int32_t Total(RE::StaticFunctionTag*,RE::BSFixedString token) {
    auto r=result(token);return r?static_cast<std::int32_t>(r->total):0;
}
void Cancel(RE::StaticFunctionTag*) {if(auto current=service.load())current->reset();}
bool Bind(RE::BSScript::IVirtualMachine* vm) {
    vm->RegisterFunction("Version","CC_Native",Version);
    vm->RegisterFunction("Submit","CC_Native",Submit);
    vm->RegisterFunction("Ready","CC_Native",Ready);
    vm->RegisterFunction("Status","CC_Native",Status);
    vm->RegisterFunction("Results","CC_Native",Results);
    vm->RegisterFunction("Page","CC_Native",Page);
    vm->RegisterFunction("Total","CC_Native",Total);
    vm->RegisterFunction("Cancel","CC_Native",Cancel);
    return true;
}
void Message(SKSE::MessagingInterface::Message* message) {
    if(message->type==SKSE::MessagingInterface::kDataLoaded) {
        try {initializeProvider();}
        catch(const std::exception& e){
            try{std::ofstream(stateDirectory()/"graph-build.log")<<"Initialization error: "<<e.what()<<'\n';}catch(...){}
        }
    }
    if(message->type==SKSE::MessagingInterface::kPreLoadGame||
       message->type==SKSE::MessagingInterface::kNewGame)
        if(auto current=service.load())current->reset();
}
}
extern "C" __declspec(dllexport) constinit SKSE::PluginVersionData SKSEPlugin_Version = [] {
    SKSE::PluginVersionData data;
    data.PluginName("CombatCompass");
    data.PluginVersion({0,2,2,0});
    data.CompatibleVersions({REL::Version{1,6,1170,0}, REL::Version{1,7,104,0}});
    data.UsesAddressLibrary();
    data.UsesUpdatedStructs();
    return data;
}();
extern "C" __declspec(dllexport) bool SKSEPlugin_Load(const SKSE::LoadInterface* skse) {
    if(skse->IsEditor())return false;
    const auto runtime=skse->RuntimeVersion();
    if(runtime!=REL::Version{1,6,1170,0}&&runtime!=REL::Version{1,7,104,0})return false;
    SKSE::Init(skse);
    auto papyrus=SKSE::GetPapyrusInterface();
    auto messaging=SKSE::GetMessagingInterface();
    if(!papyrus||!messaging)return false;
    return papyrus->Register(Bind)&&messaging->RegisterListener(Message);
}
