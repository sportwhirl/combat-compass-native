#include "Routing.hpp"
#include <algorithm>
#include <bit>
#include <cmath>
#include <iomanip>
#include <limits>
#include <locale>
#include <sstream>
#include <stdexcept>
#include <tuple>

namespace cc {
namespace {
Vec sub(Vec a, Vec b) { return {a.x-b.x,a.y-b.y,a.z-b.z}; }
Vec add(Vec a, Vec b) { return {a.x+b.x,a.y+b.y,a.z+b.z}; }
Vec mul(Vec a, double s) { return {a.x*s,a.y*s,a.z*s}; }
double dot(Vec a, Vec b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
bool finite(Vec p) {
    return std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z)
        &&std::abs(p.x)<1e7&&std::abs(p.y)<1e7&&std::abs(p.z)<1e7;
}
std::optional<Vec> project(Vec p, const std::array<Vec,3>& v) {
    auto a=v[0],b=v[1],c=v[2];
    double den=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);
    if (std::abs(den)<1e-7) return {};
    double u=((b.y-c.y)*(p.x-c.x)+(c.x-b.x)*(p.y-c.y))/den;
    double w=((c.y-a.y)*(p.x-c.x)+(a.x-c.x)*(p.y-c.y))/den;
    double t=1-u-w;
    if (std::min({u,w,t}) < -1e-6) return {};
    double z=u*a.z+w*b.z+t*c.z;
    if (std::abs(p.z-z)>256) return {};
    return Vec{p.x,p.y,z};
}
Vec closest(Vec p, const std::array<Vec,3>& v) {
    auto ab=sub(v[1],v[0]), ac=sub(v[2],v[0]);
    Vec n{ab.y*ac.z-ab.z*ac.y, ab.z*ac.x-ab.x*ac.z, ab.x*ac.y-ab.y*ac.x};
    Vec result=v[0]; double best=distance(p,result);
    auto accept=[&](Vec q){ double d=distance(p,q); if(d<best){best=d;result=q;} };
    if (dot(n,n)>0) {
        Vec q=sub(p,mul(n,dot(sub(p,v[0]),n)/dot(n,n)));
        if (project(q,v)) accept(q);
    }
    for (int i=0;i<3;++i) {
        Vec a=v[i], e=sub(v[(i+1)%3],a);
        double t=dot(e,e)>0 ? std::clamp(dot(sub(p,a),e)/dot(e,e),0.0,1.0) : 0;
        accept(add(a,mul(e,t)));
    }
    return result;
}
std::uint32_t u32(std::istream& in) {
    unsigned char b[4]; in.read(reinterpret_cast<char*>(b),4);
    if (!in) throw std::runtime_error("Truncated native dataset");
    return b[0]|(std::uint32_t(b[1])<<8)|(std::uint32_t(b[2])<<16)|(std::uint32_t(b[3])<<24);
}
std::int32_t i32(std::istream& in) { return std::bit_cast<std::int32_t>(u32(in)); }
double f32(std::istream& in) {
    auto v=std::bit_cast<float>(u32(in));
    if(!std::isfinite(v)) throw std::runtime_error("Nonfinite dataset value");
    return v;
}
double f64(std::istream& in) {
    std::uint64_t lo=u32(in), hi=u32(in);
    auto v=std::bit_cast<double>(lo|(hi<<32));
    if(!std::isfinite(v)) throw std::runtime_error("Nonfinite dataset coordinate");
    return v;
}
Vec vec64(std::istream& in) { auto x=f64(in), y=f64(in), z=f64(in); return {x,y,z}; }
Vec vec(std::istream& in) { auto x=f32(in), y=f32(in), z=f32(in); return {x,y,z}; }
std::string str(std::istream& in) {
    auto n=u32(in); if(n>4096) throw std::runtime_error("Oversized dataset string");
    std::string s(n,'\0'); in.read(s.data(),n);
    if(!in || s.find('\0')!=std::string::npos) throw std::runtime_error("Bad dataset string");
    return s;
}
std::string quote(const std::string& s) {
    std::ostringstream out; out<<'"';
    for(unsigned char c:s) {
        if(c=='"'||c=='\\') out<<'\\'<<c;
        else if(c<32) out<<"\\u"<<std::hex<<std::setw(4)<<std::setfill('0')<<int(c)<<std::dec;
        else out<<c;
    }
    out<<'"'; return out.str();
}
}
double distance(Vec a, Vec b) { auto d=sub(a,b); return std::sqrt(dot(d,d)); }
Router Router::read(std::istream& in) {
    char magic[8]; in.read(magic,8);
    if (!in || std::string(magic,8)!="CCNAV001") throw std::runtime_error("Wrong dataset format");
    Router r;
    auto count=u32(in), targetCount=u32(in);
    if(count==0 || count>5000000 || targetCount>10000) throw std::runtime_error("Dataset count out of bounds");
    // Sequential append avoids a huge allocation for a truncated/malicious header.
    for(std::uint32_t i=0;i<count;++i) {
        Node n; auto flags=u32(in);
        if(flags>1) throw std::runtime_error("Bad node flags");
        n.valid=flags!=0; n.cellX=i32(in); n.cellY=i32(in);
        for(auto& v:n.triangle) v=vec(in);
        n.center=vec(in);
        for(auto& a:n.adjacent) a=i32(in);
        for(auto& c:n.costs) c=f32(in);
        r.nodes.push_back(n);
    }
    for(std::uint32_t i=0;i<targetCount;++i) {
        Target t; t.key=str(in);t.name=str(in);t.reference=str(in);t.arrivalPlugin=str(in);
        t.arrivalID=u32(in);t.difficulty=i32(in);t.position=vec64(in);
        r.targets.push_back(std::move(t));
    }
    if(in.peek()!=std::char_traits<char>::eof()) throw std::runtime_error("Trailing dataset bytes");
    r.prepare(); return r;
}

void Router::write(std::ostream& out) const {
    auto put32=[&](std::uint32_t n) {
        unsigned char b[4]{static_cast<unsigned char>(n),static_cast<unsigned char>(n>>8),
                           static_cast<unsigned char>(n>>16),static_cast<unsigned char>(n>>24)};
        out.write(reinterpret_cast<char*>(b),4);
    };
    auto putFloat=[&](double n){put32(std::bit_cast<std::uint32_t>(static_cast<float>(n)));};
    auto putVec=[&](Vec p){putFloat(p.x);putFloat(p.y);putFloat(p.z);};
    auto putString=[&](const std::string& s){put32(static_cast<std::uint32_t>(s.size()));out.write(s.data(),s.size());};
    out.write("CCNAV001",8);put32(static_cast<std::uint32_t>(nodes.size()));put32(static_cast<std::uint32_t>(targets.size()));
    for(auto& n:nodes) {
        put32(n.valid?1:0);put32(std::bit_cast<std::uint32_t>(n.cellX));put32(std::bit_cast<std::uint32_t>(n.cellY));
        for(auto p:n.triangle)putVec(p);
        putVec(n.center);
        for(auto a:n.adjacent)put32(std::bit_cast<std::uint32_t>(a));
        for(auto cost:n.costs)putFloat(cost);
    }
    for(auto& t:targets) {
        putString(t.key);putString(t.name);putString(t.reference);putString(t.arrivalPlugin);
        put32(t.arrivalID);put32(static_cast<std::uint32_t>(t.difficulty));
        for(double n:{t.position.x,t.position.y,t.position.z}) {
            auto bits=std::bit_cast<std::uint64_t>(n);
            put32(static_cast<std::uint32_t>(bits));put32(static_cast<std::uint32_t>(bits>>32));
        }
    }
}

void Router::prepare() {
    cells_.clear(); start_=-1; best_.clear();settled_.clear();queue_={};
    std::set<std::string> keys;
    for(std::size_t i=0;i<nodes.size();++i) {
        auto& n=nodes[i];
        if(!finite(n.center) || std::abs(std::int64_t(n.cellX))>3000 || std::abs(std::int64_t(n.cellY))>3000)
            throw std::runtime_error("Bad node geometry");
        for(auto p:n.triangle) if(!finite(p)) throw std::runtime_error("Bad triangle");
        for(int e=0;e<3;++e) {
            auto a=n.adjacent[e]; double cost=n.costs[e];
            if(a < -1 || (a>=0 && std::size_t(a)>=nodes.size()) || !std::isfinite(cost) || cost<0)
                throw std::runtime_error("Bad graph edge");
            if(a>=0 && (!n.valid || !nodes[a].valid ||
                std::find(nodes[a].adjacent.begin(),nodes[a].adjacent.end(),std::int32_t(i))==nodes[a].adjacent.end()))
                throw std::runtime_error("Nonreciprocal graph edge");
        }
        if(n.valid) cells_[{n.cellX,n.cellY}].push_back(static_cast<std::uint32_t>(i));
    }
    for(auto& t:targets) {
        if(t.key.empty()||!keys.insert(t.key).second||t.reference.empty()||
            t.difficulty<0||t.difficulty>10||!finite(t.position)) throw std::runtime_error("Invalid target");
        t.node=-1;
        if(auto loc=locate(t.position)) { t.node=static_cast<std::int32_t>(loc->node); t.projected=loc->point; }
    }
}
std::optional<Location> Router::locate(Vec p,bool connector,double maxHeight) const {
    if(!finite(p)) return {};
    int gx=int(std::floor(p.x/4096)), gy=int(std::floor(p.y/4096));
    int minX=gx-1,maxX=gx+1,minY=gy-1,maxY=gy+1;
    if(connector) {
        minX=int(std::floor((p.x-4096)/4096));maxX=int(std::floor((p.x+4096)/4096));
        minY=int(std::floor((p.y-4096)/4096));maxY=int(std::floor((p.y+4096)/4096));
    }
    std::optional<Location> result; double best=std::numeric_limits<double>::infinity();
    for(int y=minY;y<=maxY;++y) for(int x=minX;x<=maxX;++x) {
        auto cell=cells_.find({x,y});if(cell==cells_.end())continue;
        for(auto index:cell->second) {
            auto& n=nodes[index];
            auto q=connector ? std::optional<Vec>(closest(p,n.triangle)) : project(p,n.triangle);
            if(!q)continue;
            double d=connector ? distance(p,*q) : std::abs(p.z-q->z);
            if(connector && (d>4096||std::abs(p.z-q->z)>maxHeight))continue;
            if(d<best || (d==best && (!result||index<result->node))) {best=d;result=Location{index,*q};}
        }
    }
    return result;
}
Response Router::search(const Request& req,const std::function<bool()>& cancelled) {
    if(req.token.empty()||req.token.size()>128||!finite(req.position)||req.band<0||req.band>3||
        req.page<0||req.page>100000||req.cleared.size()>10000) throw std::runtime_error("Invalid request");
    Response out;out.token=req.token;out.band=req.band;
    auto check=[&] { if(cancelled&&cancelled()) throw Cancelled{}; }; check();
    auto start=locate(req.position);
    if(!start) {
        start=locate(req.position,true);
        if(start)out.connector=distance(req.position,start->point);
    }
    if(!start) {out.status="start_not_on_walkable_navmesh";return out;}
    out.status="static_navmesh_estimate";
    if(start_!=start->node) {
        start_=start->node;best_.assign(nodes.size(),std::numeric_limits<double>::infinity());
        settled_.assign(nodes.size(),false);queue_={};
        best_[start->node]=0;queue_.push({0,start->node});
    }
    const int lo[]={0,0,4,8},hi[]={10,3,7,10};
    std::vector<const Target*> chosen;
    std::set<std::uint32_t> pending;
    for(auto& t:targets) {
        if(t.node<0 || req.cleared.contains(t.key)||t.difficulty<lo[req.band]||t.difficulty>hi[req.band])continue;
        chosen.push_back(&t);
        if(!settled_[t.node])pending.insert(t.node);
    }
    std::size_t iterations=0;
    while(!queue_.empty()&&!pending.empty()) {
        if((iterations++%1024)==0)check();
        auto [d,n]=queue_.top();queue_.pop();
        if(settled_[n]||d!=best_[n])continue;
        settled_[n]=true;++out.visited;pending.erase(n);
        for(int e=0;e<3;++e) {
            auto dest=nodes[n].adjacent[e];if(dest<0)continue;
            double cost=d+nodes[n].costs[e];
            if(cost<best_[dest]) {best_[dest]=cost;queue_.push({cost,static_cast<std::uint32_t>(dest)});}
        }
    }
    check();
    std::vector<Row> ranked;
    double initial=distance(start->point,nodes[start->node].center);
    for(auto t:chosen) {
        if(!settled_[t->node])continue;
        double d=best_[t->node]+initial+distance(nodes[t->node].center,t->projected);
        if(std::uint32_t(t->node)==start->node)d=distance(start->point,t->projected);
        // Match the existing two-decimal route-distance contract (ties-to-even).
        d=std::nearbyint((d+out.connector)*100)/100;
        double rating=t->difficulty ? t->difficulty : 5;
        ranked.push_back({*t,d,d*0.0142875+(rating*rating-1)*750/9});
    }
    std::sort(ranked.begin(),ranked.end(),[](auto& a,auto& b){
        return std::tie(a.units,a.target.key)<std::tie(b.units,b.target.key);
    });
    std::set<std::string> references;
    std::erase_if(ranked,[&](auto& row){return !references.insert(row.target.reference).second;});
    std::sort(ranked.begin(),ranked.end(),[](auto& a,auto& b){
        return std::tie(a.score,a.units,a.target.key)<std::tie(b.score,b.units,b.target.key);
    });
    out.total=ranked.size();out.page=std::min(req.page,int(out.total ? (out.total-1)/10 : 0));
    std::size_t offset=std::size_t(out.page)*10,end=std::min(offset+10,out.total);
    out.hasNext=end<out.total;
    out.rows.assign(ranked.begin()+offset,ranked.begin()+end);
    return out;
}
std::string Response::resultsJSON() const {
    std::ostringstream s;s.imbue(std::locale::classic());s<<std::setprecision(12)<<'[';
    bool first=true;
    for(auto& r:rows) {
        if(!first)s<<',';
        first=false;auto& t=r.target;
        s<<"{\"key\":"<<quote(t.key)<<",\"name\":"<<quote(t.name)
         <<",\"difficulty\":"<<t.difficulty<<",\"distance_units\":"<<r.units
         <<",\"world\":\"skyrim.esm|00003C\",\"reference\":"<<quote(t.reference)
         <<",\"position\":["<<t.position.x<<','<<t.position.y<<','<<t.position.z<<']'
         <<",\"arrival_cell_plugin\":"<<quote(t.arrivalPlugin)<<",\"arrival_cell_id\":"<<t.arrivalID<<'}';
    }
    return s.str()+']';
}
}
