#include "Service.hpp"
namespace cc {
Service::Service(Loader loader):loader_(std::move(loader)),worker_([this]{run();}) {}
Service::~Service() {
    stopping_=true;++generation_;wake_.notify_all();
    if(worker_.joinable())worker_.join();
}
bool Service::submit(Request request) {
    if(request.token.empty()||request.token.size()>128||request.cleared.size()>10000)return false;
    std::lock_guard lock(mutex_);
    pending_=Job{++generation_,std::move(request)};result_.reset();wake_.notify_one();return true;
}
void Service::reset() {
    std::lock_guard lock(mutex_);
    ++generation_;pending_.reset();result_.reset();
}
std::optional<Response> Service::response(const std::string& token) const {
    std::lock_guard lock(mutex_);
    if(result_&&result_->token==token)return result_;
    return {};
}
void Service::run() {
    std::unique_ptr<Router> router;
    while(!stopping_) {
        Job job;
        {
            std::unique_lock lock(mutex_);
            wake_.wait(lock,[&]{return stopping_||pending_.has_value();});
            if(stopping_)return;
            job=std::move(*pending_);pending_.reset();
        }
        Response response;response.token=job.request.token;response.band=job.request.band;
        try {
            if(!router)router=std::make_unique<Router>(loader_());
            response=router->search(job.request,[&]{return stopping_||generation_!=job.generation;});
        } catch(const Cancelled&) {continue;}
          catch(const std::exception&) {response.status="native_backend_unavailable";}
        std::lock_guard lock(mutex_);
        if(!stopping_&&generation_==job.generation)result_=std::move(response);
    }
}
}
