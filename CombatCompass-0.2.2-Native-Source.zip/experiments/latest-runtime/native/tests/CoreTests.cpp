#include "Routing.hpp"
#include "Service.hpp"
#include <cassert>
#include <chrono>
#include <cmath>
#include <future>
#include <iostream>
#include <sstream>
#include <thread>
using namespace cc;
Router fixture() {
    Router r;
    Node a; a.valid=true;a.triangle={Vec{0,0,0},Vec{100,0,0},Vec{0,100,0}};a.center={33,33,0};
    Node b=a;b.triangle={Vec{100,0,0},Vec{100,100,0},Vec{0,100,0}};b.center={67,67,0};
    Node island=a;island.triangle={Vec{200,0,0},Vec{300,0,0},Vec{200,100,0}};island.center={233,33,0};
    a.adjacent[0]=1;a.costs[0]=50;b.adjacent[0]=0;b.costs[0]=50;
    r.nodes={a,b,island};
    for(int i=0;i<25;++i) {
        Target t;t.key="target-"+std::to_string(i);t.name=t.key;t.reference=t.key;
        t.difficulty=i%10+1;t.position={double(1+i),10,0};r.targets.push_back(t);
    }
    Target hard;hard.key="island";hard.name="Island";hard.reference="island";hard.difficulty=1;hard.position={220,20,0};
    r.targets.push_back(hard);r.prepare();return r;
}
Response wait(Service& s,const std::string& token) {
    for(int i=0;i<2000;++i) {
        if(auto r=s.response(token))return *r;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    throw std::runtime_error("Service timeout");
}
int main() {
    auto r=fixture();Request q{"one",{10,10,0},0,0,{}};
    auto a=r.search(q);assert(a.total==25&&a.rows.size()==10&&a.hasNext);
    for(auto& row:a.rows)assert(row.target.key!="island");
    q.page=1;auto b=r.search(q);assert(b.rows.size()==10&&b.visited==0);
    std::set<std::string> first;for(auto& row:a.rows)first.insert(row.target.key);
    for(auto& row:b.rows)assert(!first.contains(row.target.key));
    q.page=99999;auto last=r.search(q);assert(last.page==2&&last.rows.size()==5&&!last.hasNext);
    q.cleared=first;q.page=0;auto cleared=r.search(q);assert(cleared.total==15);
    for(auto& row:cleared.rows)assert(!first.contains(row.target.key));
    q.cleared.clear();q.band=3;auto high=r.search(q);
    for(auto& row:high.rows)assert(row.target.difficulty>=8); // No level gate.
    q.band=1;auto low=r.search(q);
    for(auto& row:low.rows)assert(row.target.difficulty<=3);
    q.band=0;q.position={-10,10,0};auto off=r.search(q);assert(off.connector==10&&off.total==25);
    q.position={-5000,10,0};assert(r.search(q).status=="start_not_on_walkable_navmesh");
    q.position={-10,10,600};assert(r.search(q).status=="start_not_on_walkable_navmesh");
    q.position={10,10,0};
    try{r.search(q,[]{return true;});assert(false);}catch(const Cancelled&){}
    q.band=5;try{r.search(q);assert(false);}catch(const std::runtime_error&){}
    // Duplicate entrance records are collapsed before difficulty ranking.
    auto dup=r.targets[0];dup.key="duplicate";r.targets.push_back(dup);r.prepare();
    q.band=0;assert(r.search(q).total==25);
    // JSON escaping preserves names without creating extra fields.
    r.targets[0].name="A \"quote\"\n";r.targets.back().name=r.targets[0].name;r.prepare();
    assert(r.search(q).resultsJSON().find("\\u000a")!=std::string::npos);
    // Geometry/edge corruption fails closed.
    auto bad=fixture();bad.nodes[0].adjacent[0]=200;
    try{bad.prepare();assert(false);}catch(const std::runtime_error&){}
    std::istringstream truncated("CCNAV001");
    try{Router::read(truncated);assert(false);}catch(const std::runtime_error&){}
    // Force an in-flight old request across a newer submission, then a reset.
    std::promise<void> loading,release;auto gate=release.get_future().share();
    Service service([&]{loading.set_value();gate.wait();return fixture();});
    q.token="old";assert(service.submit(q));loading.get_future().wait();
    q.token="new";assert(service.submit(q));release.set_value();
    assert(wait(service,"new").token=="new");assert(!service.response("old"));
    service.reset();assert(!service.response("new"));
    Service broken([]()->Router{throw std::runtime_error("Missing graph");});
    q.token="error";broken.submit(q);assert(wait(broken,"error").status=="native_backend_unavailable");
    std::cout<<"Native geometry, routing, filtering, pagination, corruption, cancellation and async lifecycle checks passed.\n";
}
