// Checks Windows loader dependencies and exported SKSE entry points only.
// Deliberately never calls SKSEPlugin_Load outside the game.
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <iostream>
int main(int argc,char** argv) {
    if(argc!=2) {std::cerr<<"Usage: native-load-probe CombatCompass.dll\n";return 2;}
    HMODULE dll=LoadLibraryA(argv[1]);
    if(!dll) {std::cerr<<"LoadLibrary failed: "<<GetLastError()<<'\n';return 1;}
    bool ok=GetProcAddress(dll,"SKSEPlugin_Load")&&GetProcAddress(dll,"SKSEPlugin_Version");
    std::cout<<(ok ? "Windows loader and SKSE exports passed. Game entry point NOT invoked.\n" :
                      "Required SKSE exports missing.\n");
    FreeLibrary(dll);
    return ok ? 0 : 1;
}
