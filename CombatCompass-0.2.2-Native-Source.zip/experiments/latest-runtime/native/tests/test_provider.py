"""Synthetic ESP fixtures test the native reader; no proprietary record payloads."""
import json,os,struct,subprocess,tempfile,unittest,zlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
EXE=ROOT/'build/native-cmake/data-probe'
def sub(tag,data):return tag.encode()+struct.pack('<H',len(data))+data
def record(tag,fid,data=b'',flags=0):
    return tag.encode()+struct.pack('<III',len(data),flags,fid)+b'\0'*8+data
def group(label,kind,data):return b'GRUP'+struct.pack('<III',len(data)+24,label,kind)+b'\0'*8+data
def header(master=None):
    data=sub('HEDR',struct.pack('<fII',1.7,5,0x800))
    if master:data+=sub('MAST',master.encode()+b'\0')+sub('DATA',b'\0'*8)
    # Exercise repeated TES4 subrecords and XXXX extended lengths.
    data+=sub('XXXX',struct.pack('<I',70000))+b'ONAM\0\0'+b'\0'*70000
    return record('TES4',0,data)
def nav(flags=0,broken=False):
    data=struct.pack('<IIIhhI',12,0,0x3c,0,0,3)
    data+=struct.pack('<9f',0,0,0,100,0,0,0,100,0)
    data+=struct.pack('<I6h2HII',1,0,1,2,-1,-1,-1,flags,0,0,0)
    raw=sub('NVNM',data);compressed=zlib.compress(raw)
    if broken:compressed=compressed[:-1]+bytes([compressed[-1]^1])
    return record('NAVM',0x200,struct.pack('<I',len(raw))+compressed,0x40000)
def ref(x=10,deleted=False):
    return record('REFR',0x100,sub('DATA',struct.pack('<6f',x,10,0,0,0,0)),0x20 if deleted else 0)
def world(data):
    return group(0x3c,1,record('CELL',0x30,sub('DATA',b'\0'))+group(0x30,6,data))
class ProviderTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.base=self.root/'Skyrim.esm';self.base.write_bytes(header()+world(nav()+ref()))
        self.cat=self.root/'catalog.tsv';self.cat.write_text('CCCATALOG1\nfixture\tSynthetic encounter\t1\tskyrim.esm|000100\treference\n')
    def tearDown(self):self.tmp.cleanup()
    def run_probe(self,extra=None,success=True):
        sources=[self.base]+(extra or [])
        manifest=self.root/'inputs.tsv'
        manifest.write_text(''.join(p.name+'\t'+str(p)+'\n' for p in sources))
        proc=subprocess.run([str(EXE),str(manifest),str(self.cat),str(self.root/'cache')],
            input='test 1 1 0 0 0\n',text=True,capture_output=True,timeout=15)
        self.assertEqual(proc.returncode,0 if success else 1,proc.stderr)
        return (json.loads(proc.stdout) if success else None),proc.stderr
    def test_compressed_geometry_and_cache(self):
        result,log=self.run_probe();self.assertEqual(result['total'],1);self.assertIn('cache_hit=0',log)
        _,log=self.run_probe();self.assertIn('cache_hit=1',log)
        cache=next((self.root/'cache').glob('*.ccg'));data=bytearray(cache.read_bytes());data[-1]^=1;cache.write_bytes(data)
        result,log=self.run_probe();self.assertIn('cache_hit=0',log);self.assertEqual(result['total'],1)
    def test_winning_override_and_same_stat_content_change(self):
        patch=self.root/'Patch.esl';patch.write_bytes(header('Skyrim.esm')+world(ref(20)))
        result,_=self.run_probe([patch]);self.assertEqual(result['results'][0]['position'][0],20)
        old=patch.stat();patch.write_bytes(header('Skyrim.esm')+world(ref(30)))
        os.utime(patch,ns=(old.st_atime_ns,old.st_mtime_ns))
        result,log=self.run_probe([patch]);self.assertEqual(result['results'][0]['position'][0],30);self.assertIn('cache_hit=0',log)
    def test_deleted_ref_and_water_override(self):
        patch=self.root/'Patch.esp';patch.write_bytes(header('Skyrim.esm')+world(ref(deleted=True)))
        result,_=self.run_probe([patch]);self.assertEqual(result['total'],0)
        patch.write_bytes(header('Skyrim.esm')+world(nav(512)))
        result,_=self.run_probe([patch]);self.assertEqual(result['status'],'start_not_on_walkable_navmesh')
    def test_missing_master_and_bad_compression(self):
        patch=self.root/'Patch.esp';patch.write_bytes(header('Missing.esm'))
        _,log=self.run_probe([patch],False);self.assertIn('Missing or out-of-order master',log)
        self.base.write_bytes(header()+world(nav(broken=True)+ref()))
        _,log=self.run_probe(success=False);self.assertIn('Invalid compressed',log)
    def test_catalog_fingerprint(self):
        self.run_probe()
        self.cat.write_text(self.cat.read_text().replace('\t1\t','\t9\t'))
        result,log=self.run_probe();self.assertEqual(result['results'][0]['difficulty'],9);self.assertIn('cache_hit=0',log)
if __name__=='__main__':unittest.main()
