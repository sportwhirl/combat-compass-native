// Executes CommonLib's real Address Library readers; never calls game code.
#include <SKSE/SKSE.h>
#include <REL/REL.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <vector>
#include <stdexcept>
static void require(bool ok,const char* message) {
    if(!ok)throw std::runtime_error(message);
}
int main(int argc,char** argv) {
    if(argc!=4)return 2;
    try {
        auto version=REL::GetFileVersion(std::filesystem::path(argv[2]).wstring());
        require(version&&*version==REL::Version{1,7,104,0},"Latest executable version mismatch");
        require(REL::Module::mock(*version,REL::Module::Runtime::AE,L"SkyrimSE.exe",0x1000),"Runtime mock failed");
        require(REL::IDDB::inject(std::filesystem::path(argv[1]).wstring(),*version),"Format 5 load failed");
        std::ifstream file(argv[1],std::ios::binary);
        std::vector<unsigned char> bytes((std::istreambuf_iterator<char>(file)),{});
        auto u32=[&](std::size_t at) {
            require(at+4<=bytes.size(),"Truncated fixture");
            return std::uint32_t(bytes[at])|(std::uint32_t(bytes[at+1])<<8)|
                   (std::uint32_t(bytes[at+2])<<16)|(std::uint32_t(bytes[at+3])<<24);
        };
        require(u32(0)==5&&u32(84)==8&&u32(88)==0,"Unexpected address library header");
        auto count=u32(92);std::size_t checked=0;
        for(std::uint64_t id=1;id<count;++id) {
            auto expected=u32(96+id*4);
            if(expected) {
                require(REL::IDDB::get().id2offset(id)==expected,"Format 5 offset mismatch");
                ++checked;
            }
        }
        require(REL::IDDB::get().id2offset(400269)==0x219ded8,"TESDataHandler relocation mismatch");
        REL::Module::reset();
        require(REL::Module::mock(REL::Version{1,6,1170,0},REL::Module::Runtime::AE,L"SkyrimSE.exe",0x1000),"Legacy runtime mock failed");
        require(REL::IDDB::inject(std::filesystem::path(argv[3]).wstring(),REL::Version{1,6,1170,0}),"Legacy format 2 load failed");
        require(REL::IDDB::get().id2offset(11483)==0x14fcd0,"Legacy offset mismatch");
        REL::Module::reset();
        std::cout<<"PASS: actual Skyrim 1.7.104 version resource; "<<checked
                 <<" format 5 offsets; legacy 1.6.1170 format 2 lookup. Gameplay NOT tested.\n";
        return 0;
    }catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
