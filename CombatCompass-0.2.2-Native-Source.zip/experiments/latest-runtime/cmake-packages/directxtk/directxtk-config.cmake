get_filename_component(_cc_root "${CMAKE_CURRENT_LIST_DIR}/../../../.." ABSOLUTE)
if(NOT TARGET Microsoft::DirectXTK)
  add_library(Microsoft::DirectXTK STATIC IMPORTED)
  set_target_properties(Microsoft::DirectXTK PROPERTIES
    IMPORTED_LOCATION "${_cc_root}/build/latest-directxtk-simplemath/DirectXTK.lib"
    INTERFACE_INCLUDE_DIRECTORIES "${_cc_root}/vendor/native-build/DirectXTK-524c655ee0b69c33f6dfec81878596b131f79671/Inc")
endif()
