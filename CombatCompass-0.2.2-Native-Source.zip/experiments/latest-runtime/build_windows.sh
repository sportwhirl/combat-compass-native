#!/usr/bin/env bash
set -euo pipefail
CC_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
CC_CMAKE="${CC_CMAKE:-cmake}"
CC_TOOLS="$CC_ROOT/vendor/native-build"
CC_TOOLCHAIN="$CC_ROOT/native/cmake/windows-clang.cmake"
CC_LIB="$CC_TOOLS/CommonLibSSE-NG-8ffc2b74af015f837de53cc02b0cb470a15678e4"
CC_DXTK="$CC_TOOLS/DirectXTK-524c655ee0b69c33f6dfec81878596b131f79671"
python3 - "$CC_DXTK" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1])/'Inc/SimpleMath.h'
s=p.read_text()
if 'operator<= >' in s:
    assert s.count('operator<= >')==2
    p.write_text(s.replace('operator<= >','operator<=>'))
PY
"$CC_CMAKE" -S "$CC_TOOLS/spdlog" -B "$CC_ROOT/build/latest-spdlog" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$CC_TOOLCHAIN" -DCMAKE_BUILD_TYPE=Release \
  -DSPDLOG_BUILD_SHARED=OFF -DSPDLOG_INSTALL=ON \
  -DCMAKE_INSTALL_PREFIX="$CC_TOOLS/windows-prefix"
"$CC_CMAKE" --build "$CC_ROOT/build/latest-spdlog" --parallel 4
"$CC_CMAKE" --install "$CC_ROOT/build/latest-spdlog"
"$CC_CMAKE" -S "$CC_ROOT/experiments/latest-runtime/directxtk-simplemath" \
  -B "$CC_ROOT/build/latest-directxtk-simplemath" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$CC_TOOLCHAIN" -DCMAKE_BUILD_TYPE=Release \
  -DCC_DIRECTXTK_SOURCE="$CC_DXTK"
"$CC_CMAKE" --build "$CC_ROOT/build/latest-directxtk-simplemath" --parallel 2
"$CC_CMAKE" -S "$CC_ROOT/experiments/latest-runtime/native" \
  -B "$CC_ROOT/build/native-latest-windows" -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$CC_TOOLCHAIN" -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH="$CC_TOOLS/windows-prefix;$CC_ROOT/experiments/latest-runtime/cmake-packages" \
  -DCC_BUILD_SKSE=ON -DCC_COMMONLIB_SOURCE="$CC_LIB" \
  -DRAPIDCSV_INCLUDE_DIRS="$CC_TOOLS/rapidcsv/src" \
  -DSKSE_SUPPORT_PATCH_SAFETY=OFF -DCOMMONLIB_ENABLE_IPO=OFF
"$CC_CMAKE" --build "$CC_ROOT/build/native-latest-windows" --parallel 4
